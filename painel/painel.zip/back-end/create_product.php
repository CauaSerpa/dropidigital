<?php
    session_start();
    ob_start();
    include_once('../config.php');

    // Receber os dados do formulário
    $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

    // Acessa o IF quando o usuário clicar no botão
    if (empty($dados['SendAddProduct'])) {
        // var_dump($dados);

        // Tabela que sera feita a consulta
        $tabela = "tb_products";

        // QUERY cadastrar usuário no banco de dados
        $query_usuario = "INSERT INTO $tabela (shop_id, name, price, discount, video, description, categories, sku, checkout, button, redirect_url, seo_name, seo_link, seo_description) VALUES 
                                            (:shop_id, :name, :price, :discount, :video, :description, :categories, :sku, :checkout, :button, :redirect_url, :seo_name, :seo_link, :seo_description)";

        // Preparar a QUERY
        $cad_usuario = $conn_pdo->prepare($query_usuario);

        // Substituir os links pelos valores do formulário
        $cad_usuario->bindParam(':shop_id', $dados['shop_id']);
        $cad_usuario->bindParam(':name', $dados['name']);
        $cad_usuario->bindParam(':price', $dados['price']);
        $cad_usuario->bindParam(':discount', $dados['discount']);
        $cad_usuario->bindParam(':video', $dados['video']);
        $cad_usuario->bindParam(':description', $dados['description']);
        $cad_usuario->bindParam(':categories', $dados['categories']);
        $cad_usuario->bindParam(':sku', $dados['sku']);
        $cad_usuario->bindParam(':checkout', $dados['checkout']);
        $cad_usuario->bindParam(':button', $dados['button']);
        $cad_usuario->bindParam(':redirect_url', $dados['redirect_url']);
        $cad_usuario->bindParam(':seo_name', $dados['seo_name']);
        $cad_usuario->bindParam(':seo_link', $dados['seo_link']);
        $cad_usuario->bindParam(':seo_description', $dados['seo_description']);

        // Executar a QUERY
        $cad_usuario->execute();

        // Acessa o IF quando cadastrar o usuário no BD
        if ($cad_usuario->rowCount()) {

            // Receber o id do registro cadastrado
            $usuario_id = $conn_pdo->lastInsertId();

            // Endereço do diretório
            $diretorio = "imagens/$usuario_id/";

            // Criar o diretório
            mkdir($diretorio, 0755);

            // Receber os arquivos do formulário
            $arquivo = $_FILES['imagens'];
            //var_dump($arquivo);

            // Ler o array de arquivos
            for ($cont = 0; $cont < count($arquivo['name']); $cont++) {

                // Receber nome da imagem
                $nome_arquivo = $arquivo['name'][$cont];

                // Criar o endereço de destino das imagens
                $destino = $diretorio . $arquivo['name'][$cont];

                // Acessa o IF quando realizar o upload corretamente
                if (move_uploaded_file($arquivo['tmp_name'][$cont], $destino)) {
                    $query_imagem = "INSERT INTO imagens (nome_imagem, usuario_id) VALUES (:nome_imagem, :usuario_id)";
                    $cad_imagem = $conn_pdo->prepare($query_imagem);
                    $cad_imagem->bindParam(':nome_imagem', $nome_arquivo);
                    $cad_imagem->bindParam(':usuario_id', $usuario_id);

                    if ($cad_imagem->execute()) {
                        $_SESSION['msgcad'] = "<p class='green'>Usuário cadastrado com sucesso!</p>";
                        // Redireciona para a página de login ou exibe uma mensagem de sucesso
                        header("Location: " . INCLUDE_PATH_DASHBOARD . "produtos");
                        exit;
                    } else {
                        $_SESSION['msg'] = "<p class='red'>Erro ao cadastrar a imagem!</p>";
                        // Redireciona para a página de login ou exibe uma mensagem de sucesso
                        header("Location: " . INCLUDE_PATH_DASHBOARD . "produtos");
                        exit;
                    }
                } else {
                    $_SESSION['msg'] = "<p class='red'>Erro ao cadastrar a imagem!</p>";
                    // Redireciona para a página de login ou exibe uma mensagem de sucesso
                    header("Location: " . INCLUDE_PATH_DASHBOARD . "produtos");
                    exit;
                }
            }
        } else {
            $_SESSION['msg'] = "<p class='red'>Erro ao cadastrar o usuário!</p>";
            // Redireciona para a página de login ou exibe uma mensagem de sucesso
            header("Location: " . INCLUDE_PATH_DASHBOARD . "produtos");
            exit;
        }
    }