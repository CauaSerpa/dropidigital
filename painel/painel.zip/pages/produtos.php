<div class="page__header center">
    <div class="header__title">
        <h2 class="title">Produtos</h2>
        <p class="products-counter">5 produtos</p>
    </div>
    <div class="header__actions">
        <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>" class="export text-black text-decoration-none">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="m12 18 4-5h-3V2h-2v11H8z"></path><path d="M19 9h-4v2h4v9H5v-9h4V9H5c-1.103 0-2 .897-2 2v9c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-9c0-1.103-.897-2-2-2z"></path></svg>
            Importar
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path></svg>
        </a>
        <div class="container__button">
            <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>criar-produto" class="button button--flex new text-decoration-none">+ Criar Produto</a>
        </div>
    </div>
</div>

<div class="card__container grid one tabPanel" style="display: grid;">
    <div class="card__box grid">
        <div class="card table">
            <div class="card__title">
                <div class="title__content grid">
                    <form action="" class="table__actions">
                        <div class="search__container">
                            <input type="text" name="searchUsers" id="searchUsers" class="search" placeholder="Pesquisar" title="Pesquisar">
                        </div>
                        <button type="button" class="filter"data-bs-toggle="offcanvas" data-bs-target="#offcanvas" aria-controls="offcanvasExample">
                            Filtrar
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M21 3H5a1 1 0 0 0-1 1v2.59c0 .523.213 1.037.583 1.407L10 13.414V21a1.001 1.001 0 0 0 1.447.895l4-2c.339-.17.553-.516.553-.895v-5.586l5.417-5.417c.37-.37.583-.884.583-1.407V4a1 1 0 0 0-1-1zm-6.707 9.293A.996.996 0 0 0 14 13v5.382l-2 1V13a.996.996 0 0 0-.293-.707L6 6.59V5h14.001l.002 1.583-5.71 5.71z"></path></svg>
                        </button>
                    </form>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>
                            <input type="checkbox" class="form-check-input" id="checkAll">
                        </th>
                        <th>Nome</th>
                        <th>Valor</th>
                        <th>Categoria</th>
                        <th>SKU</th>
                        <th>Data de Criação</th>
                        <th>Eventos</th>
                    </tr>
                </thead>
            <?php
                // Nome da tabela para a busca
                $tabela = 'tb_products';

                $sql = "SELECT * FROM $tabela WHERE shop_id = :shop_id ORDER BY id DESC";

                // Preparar e executar a consulta
                $stmt = $conn_pdo->prepare($sql);
                $stmt->bindParam(':shop_id', $id);
                $stmt->execute();

                // Recuperar os resultados
                $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

                // Else para o foreach
                $encontrouProduto = false; // Variável de controle

                // Loop através dos resultados e exibir todas as colunas
                foreach ($resultados as $usuario) {

                    // Consulta SQL para selecionar todas as colunas com base no ID
                    $sql = "SELECT * FROM imagens WHERE usuario_id = :usuario_id ORDER BY id DESC";

                    // Preparar e executar a consulta
                    $stmt = $conn_pdo->prepare($sql);
                    $stmt->bindParam(':usuario_id', $usuario['id']);
                    $stmt->execute();

                    // Recuperar os resultados
                    $imagens = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    // Loop através dos resultados e exibir todas as colunas
                    foreach ($imagens as $imagem) {
                        //Formatacao para data
                        $date_create = date("d/m/Y", strtotime($usuario['date_create']));

                        echo '
                            <tbody>
                                <tr>
                                    <td scope="row">
                                        <input class="form-check-input itemCheckbox" type="checkbox" value="" id="defaultCheck2">
                                    </td>
                                    <td>
                                        <img src="' . INCLUDE_PATH_DASHBOARD . 'back-end/imagens/' . $imagem['usuario_id'] . '/' . $imagem['nome_imagem'] . '" alt="Capa do Produto" style="width: 38px; height: 38px; object-fit: cover;">
                                        ' . $usuario['name'] . '
                                    </td>
                                    <td>R$ ' . $usuario['price'] . '</td>
                                    <td>' . $usuario['categories'] . '</td>
                                    <td>' . $usuario['sku'] . '</td>
                                    <td>' . $date_create . '</td>
                                    <td>
                                        <a href="' . INCLUDE_PATH_DASHBOARD . 'editar-produto?id=' . $usuario['id'] . '" class="btn btn-primary">
                                            <i class="bx bx-show-alt" ></i>
                                        </a>
                                        <a href="' . INCLUDE_PATH_DASHBOARD . 'excluir-produto?id=' . $usuario['id'] . '" class="btn btn-danger">
                                            <i class="bx bxs-trash" ></i>
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        ';
                        
                        $encontrouProduto = true;
                    }
                }

                if (!$encontrouProduto) {
                    echo 'Você não possui nenhuma cobrança ativa!';
                }
            ?>
            </table>
        </div>
        <div class="center">
            <div class="left">
                <div class="container__button">
                    <div class="limitPageDropdown dropdown button button--flex select">
                        <input type="text" class="text02" placeholder="10" readonly="">
                        <div class="option">
                            <div onclick="show('10')">10</div>
                            <div onclick="show('20')">20</div>
                            <div onclick="show('30')">30</div>
                            <div onclick="show('40')">40</div>
                            <div onclick="show('50')">50</div>
                        </div>
                    </div>
                    <label>Produtos por página</label>
                </div>
            </div>
            <div class="right grid">
                <div class="controller">
                    <span class="analog pag-link active pag-link">1</span>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function() {
        $('#checkAll').on('click', function() {
            $('.itemCheckbox').prop('checked', $(this).prop('checked'));
        });
            
        $('.itemCheckbox').on('click', function() {
            $('#checkAll').prop('indeterminate', true);

            if ($('.itemCheckbox:checked').length === $('.itemCheckbox').length) {
                $('#checkAll').prop('indeterminate', false);
                $('#checkAll').prop('checked', true);
            } else if ($('.itemCheckbox:checked').length === 0) {
                $('#checkAll').prop('indeterminate', false);
                $('#checkAll').prop('checked', false);
            }
        });
    });
</script>