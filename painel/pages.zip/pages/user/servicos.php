<div class="page__header center">
    <div class="header__title">
        <div class="page__header center">
            <div class="header__title">
                <h2 class="title">Soluções</h2>
            </div>
        </div>
    </div>
    <div class="header__actions">
        <div class="container__button">
            <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>ajuda/solucoes" class="link-secondary link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover text-decoration-none d-flex align-items-center">
                <i class='bx bx-help-circle me-1' ></i>
                <b>Obtenha ajuda sobre</b>
            </a>
        </div>
    </div>
</div>

<div class="row g-3">
    <a href="https://pay.hotmart.com/I87196553U" target="__black" class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-1.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </a>
    <a href="https://mpago.la/1b4q8Mk" target="__black" class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-2.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </a>
    <a href="https://mpago.la/2gmWgJQ" target="__black" class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-3.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </a>
    <a herf="https://mpago.la/2aJm9Bz" target="__black" class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-4.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </a>
    <a href="https://mpago.la/1piXCSS" target="__black" class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-5.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </a>
    <a href="https://mpago.li/25cjbHY" target="__black" class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-6.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </a>
    <a href="https://mpago.li/2NoQfiV" target="__black" class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-7.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </a>
    <div class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-8.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </div>
    <div class="col-sm-4">
        <img src="<?php echo INCLUDE_PATH; ?>assets/images/home-banners/banner-9.jpeg" class="w-100 rounded-2" alt="Anúncio Banner">
    </div>
</div>