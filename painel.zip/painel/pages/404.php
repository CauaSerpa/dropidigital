<div class="box__container login">
    <nav class="nav">
        <a href="<?php echo INCLUDE_PATH; ?>" class="form__logo">
            <img src="<?php echo INCLUDE_PATH; ?>assets/images/logos/logo-one.png" alt="Logo">
        </a>
    </nav>
    <div class="error-404">
        <h2>Página não encontrada</h2>
        <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>">Voltar</a>
    </div>
    <div class="bottom__text signup">
        <p>Ainda possui uma loja na DropiDigital?</p>
        <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>signup/">Crie sua loja virtual grátis agora.</a>
    </div>
</div>