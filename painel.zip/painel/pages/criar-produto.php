<div class="system-message">
    <p>Boa Noite</p>
    <h1></h1>
</div>