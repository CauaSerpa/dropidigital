<?php
    session_start();
    ob_start();
    include('config.php');

    if((!isset($_SESSION['id']) == true) and (!isset($_SESSION['password']) == true))
    {
        $_SESSION['msgcad'] = "<p style='color: #ff0000'>É necessário realizar o login para acessar a página!</p>";
        unset($_SESSION['cnpj']);
        unset($_SESSION['razao_social']);
        header("Location: ".INCLUDE_PATH_DASHBOARD."login/");
    }

    if(!empty($_SESSION['id']))
    {
        include_once('config.php');

        $id = $_SESSION['id'];
        $email = $_SESSION['email'];
        $phone = $_SESSION['phone'];
        $cargo = $_SESSION['cargo'];

        if ($cargo == 0)
        {
            $table = '`tb_users.personal`';
        }
        if ($cargo == 1)
        {
            $table = '`tb_users.business`';
        }
        if ($cargo == 2)
        {
            $table = '`tb_users.admin`';
        }
        
        $sqlSelect = "SELECT * FROM $table WHERE id='$id'";
        
        $result = $conn->query($sqlSelect);
        
        if($result->num_rows > 0)
        {
            while ($data = mysqli_fetch_assoc($result))
            {
                @$id = $data['id'];
                @$status = $data['status'];
                @$name = $data['name'];
                @$complete_name = $data['complete_name'];
                @$email = $data['email'];
                @$razao_social = $data['razao_social'];
                @$recup_email = $data['recup_email'];
                @$cnpj = $data['cnpj'];
                @$sector = $data['sector'];
                @$public_email = $data['public_email'];
                @$description = $data['description'];
                @$address = $data['address'];
                @$address_number = $data['address_number'];
                @$logo = $data['logo'];
                @$theme_color = $data['theme_color'];
                @$link = $data['link'];
                @$relatorio = $data['relatorio'];
            }
        }
        
        $sqlSelectAddress = "SELECT * FROM `tb_users.address` WHERE user_id='$id'";

        $resultAddress = $conn->query($sqlSelectAddress);
        
        if($resultAddress->num_rows > 0)
        {
            while ($data = mysqli_fetch_assoc($resultAddress))
            {
                @$cep = $data['cep'];
                @$rua = $data['rua'];
                @$numero = $data['numero'];
                @$complemento = $data['complemento'];
                @$bairro = $data['bairro'];
                @$cidade = $data['cidade'];
                @$uf = $data['uf'];
            }
        }
        
        $result_n = "SELECT COUNT(id) AS num_result FROM `tb_notifications` WHERE visibility LIKE $_SESSION[cargo] or visibility LIKE 2 ORDER BY id DESC";
        $resultado_n = mysqli_query($conn, $result_n);
        $row_n = mysqli_fetch_assoc($resultado_n);
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Habilide</title>

    <!--Favicon-->
    <link rel="shortcut icon" href="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/img/logo.png" type="image/x-icon">
    <!--CSS-->
    <!--Painel-->
    <link rel="stylesheet" href="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/css/style.css">
    <!--Login-->
    <link rel="stylesheet" href="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/css/login.css">
    <!--Box Icons-->
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <!--Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Intro JS -->
    <link href="https://cdn.jsdelivr.net/npm/intro.js@7.0.1/minified/introjs.min.css" rel="stylesheet">
</head>
<body>
    <?php
        //Url Amigavel
        $url = isset($_GET['url']) ? $_GET['url'] : 'painel';
        
        
        if ($url == 'login') 
        {
            echo "";
    ?>
    <header class="l-header">
        <nav class="nav bd-grid">
            <a href="<?php echo INCLUDE_PATH; ?>" class="nav__logo center">
                <img src="../assets/images/logos/logo-one.png" alt="Logo">
            </a>
        </nav>
    </header>
    <main class="main">
        <div class="container__box">
            <div class="box__slide">
                <div class="carroussel">
                    <div class="container__carroussel">
                        <div class="slide">
                            <div class="background">
                                <img src="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/img/background.svg" alt="">
                            </div>
                            <div class="slides">
                                <div id="atual" class="image">
                                    <img src="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/img/flat-icon (1).svg" alt="">
                                </div>
                                <div class="image">
                                    <img src="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/img/flat-icon (2).svg" alt="">
                                </div>
                                <div class="image">
                                    <img src="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/img/flat-icon (3).svg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container__description">
                    <div class="description">
                        <h2 class="title">Sobre a DropiDigital</h2>
                        <p class="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla lobortis lectus ac risus vulputate volutpat. Vestibulum tempor ultricies lobortis. Sed tempus diam eu laoreet iaculis. Nulla volutpat ultrices mauris, ac volutpat mi auctor at.</p>
                    </div>
                    <div class="balls"></div>
                </div>
            </div>
    <?php
            echo "";
        }
        else
        {
            echo "";
    ?>
    <div class="tutorial__bg__"></div>
    <header class="l-header">
        <nav class="nav bd-grid">
            <div class="left">
                <div class="toggle" onclick="toggle()">
                    <i class='bx bx-menu' id="mobileBtn"></i>
                </div>
                <a href="#home" class="nav__logo">
                    <img class="logo" src="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/img/logo.png" alt="">
                    <h3>HABILIDE</h3>
                </a>
                <form action="" class="search__form" data-hint="Pesquise aqui por empresas" data-hint-position="bottom-middle">
                    <div class="search__container">
                        <input type="text" name="search" id="search" class="search" placeholder="Pesquisar" title="Pesquisar" autocomplete="off">
                        <button type="button" class="button">
                            <i class='bx bxs-paper-plane' ></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="right">
                <div class="container__notifications">
                    <div class="notifications__icon" onclick="toggleNotifications()" data-hint=" Confira suas notificações" data-hint-position="right">
                        <i class='bx bx-bell' ></i>
                        <span class="number"><?php echo $row_n['num_result']; ?></span>
                    </div>
                    <div class="notifications" id="notificationsWrap">
                        <ul>
                            <?php
                                $sql = "SELECT * FROM `tb_notifications` WHERE visibility LIKE $_SESSION[cargo] or visibility LIKE 2 ORDER BY id DESC";

                                $network = $conn->query($sql);

                                while($data = mysqli_fetch_assoc($network))
                                {
                                    $visibility = $data['visibility'];
                                    if ($visibility == 0)
                                    {
                                        $visibility_value = 'Pessoas';
                                    }
                                    else if ($visibility == 1)
                                    {
                                        $visibility_value = 'Empresas';
                                    }
                                    else if ($visibility == 2)
                                    {
                                        $visibility_value = 'Global';
                                    }

                                    $dias_aberto_entrada = new DateTime($data['creation_date']);
                                    $dias_aberto_saida = new DateTime();
    
                                    $dias_aberto_intervalo = $dias_aberto_entrada->diff($dias_aberto_saida);
                                    $time_calc_days = $dias_aberto_intervalo->days;
                                    $time_calc_week = $time_calc_days/7;
                                    $time_calc_month = $time_calc_days/30;

                                    if ($time_calc_days == 1)
                                    {
                                        $time_calc = "há 1 dia";
                                    }
                                    else if ($time_calc_days < 7)
                                    {
                                        $time_calc = "há ".$time_calc_week." dias";
                                    }
                                    else if ($time_calc_days >= 7)
                                    {
                                        $time_calc = "há 1 semana";
                                    }
                                    else if ($time_calc_days > 14)
                                    {
                                        $time_calc = "há ".$time_calc_week." semanas";
                                    }
                                    else if ($time_calc_month == 1)
                                    {
                                        $time_calc = "há 1 mês";
                                    }
                                    else if ($time_calc_month > 1)
                                    {
                                        $time_calc = "há ".$time_calc_month." meses";
                                    }
                                    
                                    echo '<li class="new">';
                                    echo '<div class="container__title">';
                                    echo '<p class="title">'.$data['name'].'</p>';
                                    echo '<span class="date">'.$time_calc.'</span>';
                                    echo '</div>';
                                    echo '<span class="description">'.$data['description'].'</span>';
                                    echo '<a href="'.$data['url'].'" class="url-link">Clique aqui!</a>';
                                    echo '</li>';
                                    echo '<div class="line"></div>';
                                }
                            ?>
                        </ul>
                    </div>
                </div>
                <div class="container__user">
                    <div class="user__info" onclick="toggleUser()">
                        <img src="<?php echo INCLUDE_PATH_DASHBOARD."assets/img/".$logo; ?>" alt="">
                        <div class="info">
                            <p><?php echo $name; ?></p>
                            <span><?php echo $sector; ?></span>
                        </div>
                        <i class='bx bx-chevron-down' ></i>
                    </div>
                    <div class="user" id="userWrap">
                        <ul>
                            <li>
                                <a href="#" onclick="return deletarCookieTutorialSidebar()">
                                    <div class="container__title">
                                        <p class="title">Mostrar Tutorial</p>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>configuracoes">
                                    <div class="container__title">
                                        <p class="title">Minha Conta</p>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>php/sair.php">
                                    <div class="container__title">
                                        <p class="title">Sair</p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <nav class="sidebar tutorial__" id="nav">
        <ul class="nav-list">
            <li>
                <form action="" class="search__form">
                    <div class="search__container">
                        <input type="text" name="search" id="search" class="search" placeholder="Pesquisar" title="Pesquisar">
                        <button type="button" class="button">
                            <i class='bx bxs-paper-plane' ></i>
                        </button>
                    </div>
                </form>
            </li>
            <li class="home">
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>" <?php activeSidebarLink(''); ?> <?php activeSidebarLink('dashboard'); ?>>
                        <i class='bx <?php activeSidebarIcon(''); ?>-home' ></i>
                        <span class="nav-item">Home</span>
                    </a>
                </div>
                <span class="tutorial tooltip">Tutorial</span>
            </li>
            <li <?php echo verificaPermissaoMenu(2); ?> class="">
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>layout" <?php activeSidebarLink('layout'); ?>>
                        <i class='bx <?php activeSidebarIcon('layout'); ?>-layout'></i>
                        <span class="nav-item">Layout</span>
                    </a>
                </div>
            </li>
            <li <?php echo verificaPermissaoMenu(2); ?>>
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>notificacoes" <?php activeSidebarLink('notificacoes'); ?>>
                        <i class='bx <?php activeSidebarIcon('notificacoes'); ?>-bell'></i>
                        <span class="nav-item">Notificações</span>
                    </a>
                </div>
            </li>
            <li <?php echo verificaPermissaoMenu(2); ?>>
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>usuarios" <?php activeSidebarLink('usuarios'); ?>>
                        <i class='bx <?php activeSidebarIcon('usuarios'); ?>-user-circle'></i>
                        <span class="nav-item">Usuários</span>
                    </a>
                </div>
            </li>
            <li class="empresas">
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>empresas" <?php activeSidebarLink('empresas'); ?>>
                        <i class='bx <?php activeSidebarIcon('empresas'); ?>-grid-alt' ></i>
                        <span class="nav-item">Empresas</span>
                    </a>
                </div>
                <span class="tutorial tooltip">Tutorial</span>
            </li>
            <li <?php echo verificaPermissaoMenu(2); ?>>
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>aprovar-perfil" <?php activeSidebarLink('aprovar-perfil'); ?>>
                        <i class='bx <?php activeSidebarIcon('aprovar-perfil'); ?>-user-check'></i>
                        <span class="nav-item">Aprovar Perfil</span>
                    </a>
                </div>
            </li>
            <li <?php echo verificaPermissaoMenu(2); ?>>
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>aprovar-case" <?php activeSidebarLink('aprovar-case'); ?>>
                        <i class='bx bx-list-check' ></i>
                        <span class="nav-item">Aprovar Case</span>
                    </a>
                </div>
            </li>
            <li <?php echo verificaPermissaoMenu(1); ?>>
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>quiz" <?php activeSidebarLink('quiz'); ?> <?php activeSidebarLink('persona-b2b'); ?> <?php activeSidebarLink('persona-b2c'); ?>>
                        <i class='bx bx-list-check' ></i>
                        <span class="nav-item">Quiz</span>
                    </a>
                </div>
                <span class="tutorial tooltip">Tutorial</span>
            </li>
            <li <?php echo verificaPermissaoMenu(2); ?>>
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>carteira" <?php activeSidebarLink('carteira'); ?>>
                        <i class='bx <?php activeSidebarIcon('carteira'); ?>-wallet-alt' ></i>
                        <span class="nav-item">Carteira</span>
                    </a>
                </div>
            </li>
            <li <?php echo verificaPermissaoMenu(2); ?>>
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>chat" <?php activeSidebarLink('chat'); ?>>
                        <i class='bx <?php activeSidebarIcon('chat'); ?>-conversation' ></i>
                        <span class="nav-item">Chat</span>
                    </a>
                </div>
            </li>
            <li <?php echo verificaPermissaoMenu(1); ?>>
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>cases" <?php activeSidebarLink('cases'); ?>>
                        <i class='bx <?php activeSidebarIcon('cases'); ?>-user-pin' ></i>
                        <span class="nav-item">Cases</span>
                    </a>
                </div>
                <span class="tutorial tooltip">Tutorial</span>
            </li>
            <li class="ajuda">
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>ajuda" <?php activeSidebarLink('ajuda'); ?>>
                        <i class='bx <?php activeSidebarIcon('ajuda'); ?>-help-circle' ></i>
                        <span class="nav-item">Ajuda</span>
                    </a>
                </div>
                <span class="tutorial tooltip">Tutorial</span>
            </li>
            <li class="configuracoes">
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>configuracoes" <?php activeSidebarLink('configuracoes'); ?>>
                        <i class='bx <?php activeSidebarIcon('configuracoes'); ?>-cog' ></i>
                        <span class="nav-item">Configurações</span>
                    </a>
                </div>
                <div class="tutorial-line"></div>
                <span class="tutorial tooltip">
                    <h3>Tutorial</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur eget fermentum sem, a malesuada libero. Aenean lacus erat, cursus id imperdiet vitae, maximus sit amet risus.</p>
                    <div class="line"></div>
                    <div class="two">
                        <div class="step">1 - 9</div>
                        <div class="buttons">
                            <a href="#" class="skip">Pular Tutorial</a>
                            <button class="next">Prosseguir</button>
                        </div>
                    </div>
                </span>
            </li>
            <li class="sair">
                <div class="hidden">
                    <a href="<?php echo INCLUDE_PATH_DASHBOARD; ?>php/sair.php">
                        <i class='bx bx-door-open' ></i>
                        <span class="nav-item">Sair</span>
                    </a>
                </div>
                <span class="tutorial tooltip">Tutorial</span>
            </li>
        </ul>
    </nav>
    <?php 
            echo ""; 
        }
    ?>
    
    <main class="main container grid <?php echo ($url == "login") ? 'box' : ''; ?>">
        <?php
            if(file_exists('pages/'.$url.'.php')){
                include('pages/'.$url.'.php');
            }else{
                //a pagina nao existe
                header('Location: '.INCLUDE_PATH_DASHBOARD.'login/404');
            }
        ?>
    </main>

    
    <div class='card__info'>
        <div class='info'>
            <?php
                if(isset($_SESSION['msg'])){
                    echo $_SESSION['msg'];
                    unset($_SESSION['msg']);
                }
                if(isset($_SESSION['msgcad'])){
                    echo $_SESSION['msgcad'];
                    unset($_SESSION['msgcad']);
                }
            ?>
        </div>
    </div>

    <script src="<?php echo INCLUDE_PATH_DASHBOARD; ?>assets/js/main.js"></script>
    <script src="https://www.google.com/recaptcha/api.js?render=6LcRUkUnAAAAAJGzCTc4KTbgqgsEmwYZCTZtNp9i"></script>
    <script>
        function onClick(e) {
            e.preventDefault();
            grecaptcha.ready(function() {
                grecaptcha.execute('6LcRUkUnAAAAAJGzCTc4KTbgqgsEmwYZCTZtNp9i', {action: 'submit'}).then(function(token) {
                    // Add your logic to submit to your backend server here.
                });
            });
        }
  </script>
</body>
</html>