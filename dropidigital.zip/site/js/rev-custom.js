/*
Template: Techtrix - IT Solutions & Services HTML Template
Author: peacefulqode.com
Version: 1.0
Design and Developed by: PeacefulQode

*/

// ================main-home=========================//
var revapi13,
    tpj;
function revinit_revslider131() {
    jQuery(function () {
        tpj = jQuery;
        revapi13 = tpj("#rev_slider_13_1");
        if (revapi13 == undefined || revapi13.revolution == undefined) {
            revslider_showDoubleJqueryError("rev_slider_13_1");
        } else {
            revapi13.revolution({
                sliderLayout: "fullwidth",
                visibilityLevels: "1240,1024,778,480",
                gridwidth: "1880,1024,778,480",
                gridheight: "950,780,650,450",
                perspective: 600,
                perspectiveType: "global",
                editorheight: "950,780,650,450",
                responsiveLevels: "1240,1024,778,480",
                progressBar: { disableProgressBar: true },
                navigation: {
                    wheelCallDelay: 1000,
                    onHoverStop: false,
                    bullets: {
                        enable: true,
                        tmp: "<span class=\"tp-bullet-inner\"></span>",
                        style: "uranus",
                        hide_onmobile: true,
                        hide_under: "1365px",
                        h_align: "left",
                        h_offset: 45,
                        v_offset: 90,
                        space: 10
                    }
                },
                fallbacks: {
                    allowHTML5AutoPlayOnAndroid: true
                },
            });
        }

    });
} // End of RevInitScript
var once_revslider131 = false;
if (document.readyState === "loading") { document.addEventListener('readystatechange', function () { if ((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider131) { once_revslider131 = true; revinit_revslider131(); } }); } else { once_revslider131 = true; revinit_revslider131(); }

// ================home-modern=========================//

var revapi14,
    tpj;
function revinit_revslider141() {
    jQuery(function () {
        tpj = jQuery;
        revapi14 = tpj("#rev_slider_14_1");
        if (revapi14 == undefined || revapi14.revolution == undefined) {
            revslider_showDoubleJqueryError("rev_slider_14_1");
        } else {
            revapi14.revolution({
                sliderLayout: "fullwidth",
                visibilityLevels: "1240,1024,778,480",
                gridwidth: "1300,1024,778,480",
                gridheight: "800,680,500,300",
                perspective: 600,
                perspectiveType: "global",
                editorheight: "800,680,500,300",
                responsiveLevels: "1240,1024,778,480",
                progressBar: { disableProgressBar: true },
                navigation: {
                    wheelCallDelay: 1000,
                    onHoverStop: false,
                    arrows: {
                        enable: true,
                        tmp: "<div class=\"tp-arr-allwrapper\">	<div class=\"tp-arr-imgholder\"></div></div>",
                        style: "hades",
                        hide_onmobile: true,
                        hide_under: "1499px",
                        left: {
                            h_offset: 30
                        },
                        right: {
                            h_offset: 30
                        }
                    },
                    bullets: {
                        enable: true,
                        tmp: "<span class=\"tp-bullet-title\">{{title}}</span>",
                        style: "ares",
                        hide_over: "1499px",
                        v_offset: 15
                    }
                },
                fallbacks: {
                    allowHTML5AutoPlayOnAndroid: true
                },
            });
        }

    });
} // End of RevInitScript
var once_revslider141 = false;
if (document.readyState === "loading") { document.addEventListener('readystatechange', function () { if ((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider141) { once_revslider141 = true; revinit_revslider141(); } }); } else { once_revslider141 = true; revinit_revslider141(); }



// ================Start Up home=========================//

var revapi17,
    tpj;
function revinit_revslider171() {
    jQuery(function () {
        tpj = jQuery;
        revapi17 = tpj("#rev_slider_17_1");
        if (revapi17 == undefined || revapi17.revolution == undefined) {
            revslider_showDoubleJqueryError("rev_slider_17_1");
        } else {
            revapi17.revolution({
                sliderLayout: "fullwidth",
                visibilityLevels: "1240,1024,778,480",
                gridwidth: "1300,1024,778,480",
                gridheight: "800,680,500,300",
                perspective: 600,
                perspectiveType: "global",
                editorheight: "800,680,500,300",
                responsiveLevels: "1240,1024,778,480",
                progressBar: { disableProgressBar: true },
                navigation: {
                    wheelCallDelay: 1000,
                    onHoverStop: false,
                    arrows: {
                        enable: true,
                        style: "hesperiden",
                        hide_onmobile: true,
                        hide_under: "1499px",
                        left: {
                            h_offset: 30
                        },
                        right: {
                            h_offset: 30
                        }
                    },
                    bullets: {
                        enable: true,
                        tmp: "<span class=\"tp-bullet-title\">{{title}}</span>",
                        style: "ares",
                        hide_over: "1499px",
                        v_offset: 15
                    }
                },
                fallbacks: {
                    allowHTML5AutoPlayOnAndroid: true
                },
            });
        }

    });
} // End of RevInitScript
var once_revslider171 = false;
if (document.readyState === "loading") { document.addEventListener('readystatechange', function () { if ((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider171) { once_revslider171 = true; revinit_revslider171(); } }); } else { once_revslider171 = true; revinit_revslider171(); }




// ================It Agency=========================//

var revapi15,
    tpj;
function revinit_revslider151() {
    jQuery(function () {
        tpj = jQuery;
        revapi15 = tpj("#rev_slider_15_1");
        if (revapi15 == undefined || revapi15.revolution == undefined) {
            revslider_showDoubleJqueryError("rev_slider_15_1");
        } else {
            revapi15.revolution({
                sliderLayout: "fullwidth",
                visibilityLevels: "1240,1024,778,480",
                gridwidth: "1300,1024,778,480",
                gridheight: "980,772,587,362",
                perspective: 600,
                perspectiveType: "global",
                editorheight: "980,772,587,362",
                responsiveLevels: "1240,1024,778,480",
                progressBar: { disableProgressBar: true },
                navigation: {
                    wheelCallDelay: 1000,
                    onHoverStop: false,
                    arrows: {
                        enable: true,
                        tmp: "<div class=\"tp-arr-allwrapper\">	<div class=\"tp-arr-imgholder\"></div></div>",
                        style: "hades",
                        hide_onmobile: true,
                        hide_under: "1499px",
                        left: {
                            h_offset: 30,
                            v_offset: 60
                        },
                        right: {
                            h_offset: 30,
                            v_offset: 60
                        }
                    },
                    bullets: {
                        enable: true,
                        tmp: "<span class=\"tp-bullet-inner\"></span>",
                        style: "uranus",
                        hide_over: "1499px",
                        v_offset: 30,
                        space: 10
                    }
                },
                fallbacks: {
                    allowHTML5AutoPlayOnAndroid: true
                },
            });
        }

    });
} // End of RevInitScript
var once_revslider151 = false;
if (document.readyState === "loading") { document.addEventListener('readystatechange', function () { if ((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider151) { once_revslider151 = true; revinit_revslider151(); } }); } else { once_revslider151 = true; revinit_revslider151(); }




// ================Home Classic=========================//

var revapi11,
    tpj;
function revinit_revslider111() {
    jQuery(function () {
        tpj = jQuery;
        revapi11 = tpj("#rev_slider_11_1");
        if (revapi11 == undefined || revapi11.revolution == undefined) {
            revslider_showDoubleJqueryError("rev_slider_11_1");
        } else {
            revapi11.revolution({
                sliderLayout: "fullwidth",
                visibilityLevels: "1240,1024,778,480",
                gridwidth: "1300,1024,778,480",
                gridheight: "910,900,650,450",
                perspective: 600,
                perspectiveType: "global",
                editorheight: "910,900,650,450",
                responsiveLevels: "1240,1024,778,480",
                progressBar: { disableProgressBar: true },
                navigation: {
                    wheelCallDelay: 1000,
                    onHoverStop: false,
                    arrows: {
                        enable: true,
                        tmp: "<div class=\"tp-arr-allwrapper\">	<div class=\"tp-arr-imgholder\"></div></div>",
                        style: "hades",
                        hide_onmobile: true,
                        hide_under: "1499px",
                        left: {
                            h_offset: 30
                        },
                        right: {
                            h_offset: 30
                        }
                    },
                    bullets: {
                        enable: true,
                        tmp: "<span class=\"tp-bullet-title\">{{title}}</span>",
                        style: "ares",
                        hide_over: "1499px",
                        h_align: "left",
                        h_offset: 30,
                        v_offset: 30,
                        direction: "vertical"
                    }
                },
                fallbacks: {
                    allowHTML5AutoPlayOnAndroid: true
                },
            });
        }

    });
} // End of RevInitScript
var once_revslider111 = false;
if (document.readyState === "loading") { document.addEventListener('readystatechange', function () { if ((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider111) { once_revslider111 = true; revinit_revslider111(); } }); } else { once_revslider111 = true; revinit_revslider111(); }




// ================Software Company=========================//

var revapi18,
    tpj;
function revinit_revslider181() {
    jQuery(function () {
        tpj = jQuery;
        revapi18 = tpj("#rev_slider_18_1");
        if (revapi18 == undefined || revapi18.revolution == undefined) {
            revslider_showDoubleJqueryError("rev_slider_18_1");
        } else {
            revapi18.revolution({
                visibilityLevels: "1240,1024,778,480",
                gridwidth: "1300,1024,778,480",
                gridheight: "970,680,500,300",
                perspective: 600,
                perspectiveType: "global",
                editorheight: "970,680,500,300",
                responsiveLevels: "1240,1024,778,480",
                progressBar: { disableProgressBar: true },
                navigation: {
                    wheelCallDelay: 1000,
                    onHoverStop: false,
                    arrows: {
                        enable: true,
                        style: "hesperiden",
                        hide_onmobile: true,
                        hide_under: "1499px",
                        left: {
                            h_offset: 30
                        },
                        right: {
                            h_offset: 30
                        }
                    },
                    bullets: {
                        enable: true,
                        tmp: "<span class=\"tp-bullet-title\">{{title}}</span>",
                        style: "ares",
                        hide_over: "1499px",
                        v_offset: 15
                    }
                },
                fallbacks: {
                    allowHTML5AutoPlayOnAndroid: true
                },
            });
        }

    });
} // End of RevInitScript
var once_revslider181 = false;
if (document.readyState === "loading") { document.addEventListener('readystatechange', function () { if ((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider181) { once_revslider181 = true; revinit_revslider181(); } }); } else { once_revslider181 = true; revinit_revslider181(); }




// ================Landing Page=========================//

var revapi16,
    tpj;
function revinit_revslider161() {
    jQuery(function () {
        tpj = jQuery;
        revapi16 = tpj("#rev_slider_16_1");
        if (revapi16 == undefined || revapi16.revolution == undefined) {
            revslider_showDoubleJqueryError("rev_slider_16_1");
        } else {
            revapi16.revolution({
                sliderLayout: "fullwidth",
                visibilityLevels: "1240,1024,778,480",
                gridwidth: "1300,1024,778,480",
                gridheight: "900,900,584,470",
                perspective: 600,
                perspectiveType: "global",
                editorheight: "900,900,583.993,470",
                responsiveLevels: "1240,1024,778,480",
                progressBar: { disableProgressBar: true },
                navigation: {
                    onHoverStop: false
                },
                parallax: {
                    levels: [5, 10, 15, 20, 25, 30, 35, 40, 45, 46, 47, 48, 49, 50, 51, 30],
                    type: "mouse",
                    origo: "slidercenter",
                    speed: 0
                },
                fallbacks: {
                    allowHTML5AutoPlayOnAndroid: true
                },
            });
        }

    });
} // End of RevInitScript
var once_revslider161 = false;
if (document.readyState === "loading") { document.addEventListener('readystatechange', function () { if ((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider161) { once_revslider161 = true; revinit_revslider161(); } }); } else { once_revslider161 = true; revinit_revslider161(); }